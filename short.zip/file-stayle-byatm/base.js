﻿var apiUrl = "http://go.infinise.com/api/2.5/";


/*	GOOGLE
	----------------------------------------------------- */

eng.google = {
	pageTitle: "Google",
	logo: "google.png",
	places: {
		'Web'    :["http://www.google.com/search?q=%query%&hl=ar",		apiUrl+"?eng=google&timestamp=%time%&q=%query%"],
		'Images' : ["http://images.google.com/images?q=%query%&hl=ar",	apiUrl+"?eng=google&timestamp=%time%&q=%query%"],
		'Maps'   : ["http://maps.google.com/maps?q=%query%",			false]
	}
};




/*	Bing
	----------------------------------------------------- */

eng.bing = {
	pageTitle: "bing",
	logo: "bing.png",
	places: {
		'Web'    : ["http://www.bing.com/search?q=%query%&hl=ar",		apiUrl+"?eng=bing&timestamp=%time%&q=%query%"],
		'Images' : ["http://images.bing.com/images?q=%query%&hl=ar",	apiUrl+"?eng=bing&timestamp=%time%&q=%query%"],
		'Maps'   : ["http://maps.bing.com/maps?q=%query%",			false]
	}
};




/*	YOUTUBE
	----------------------------------------------------- */

eng.youtube = {
	pageTitle: "YouTube",
	logo: "youtube.png",
	places: {
		'Videos' : ["http://www.youtube.com/results?search_query=%query%", apiUrl+"?eng=youtube&timestamp=%time%&q=%query%"]
	},
};




/*	WIKIPEDIA
	----------------------------------------------------- */
	
eng.wikipedia = {
	pageTitle: "Wikipedia",
	logo: "wikipedia.png",
	places: {
		'Search'        : ["http://%lang%.wikipedia.org/wiki/Special:Search?search=%query%&fulltext=Search",	apiUrl+"?eng=wikipedia&timestamp=%time%&q=%query%&hl=%lang%"],
		'Go to Article' : ["http://%lang%.wikipedia.org/wiki/Special:Search?search=%query%&go=Go",				apiUrl+"?eng=wikipedia&timestamp=%time%&q=%query%&hl=%lang%"],
	},
	languages: {
		'': 'ar'

	}
};


/*	TWITTER
	----------------------------------------------------- */

eng.twitter = {
	pageTitle: "Twitter",
	logo: "twitter.png",
	places: {
		'Search Twitter' : ["http://twitter.com/search?q=%query%", false]
	}
};



/*	TWITTER
	----------------------------------------------------- */

eng.googleig = {
	pageTitle: "googleig",
	logo: "googleig.png",
	places: {
		'Search googleig' : ["https://www.google.com.eg/search?safe=active&hl=ar&site=imghp&tbm=isch&source=hp&biw=1152&bih=695&q=%query%", false]
	}
};
